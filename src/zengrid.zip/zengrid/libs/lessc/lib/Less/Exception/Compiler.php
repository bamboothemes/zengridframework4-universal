<?php


// no direct access
defined( 'ZEN_ALLOW' ) or die( 'Restricted access' );

/**
 * Compiler Exception
 *
 * @package Less
 * @subpackage exception
 */
class Less_Exception_Compiler extends Less_Exception_Parser{

}