<?php
/**
* @package   Zen Grid Framework
* @author    Joomlabamboo http://www.Jjoomlabamboo.com
* @copyright Copyright (C) Joomlabamboo
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// No Direct Access
defined('ZEN_ALLOW') or die(); 

// Duplicate of the input field
?>



<h2 class="uk-article-title"><?php echo $label;?></h2>
<p class="info"><?php echo $description;?></p>
<div id="log"><pre></pre></div>
